package com.example.android.quiz_app;

/**
 * Created by android on 9/18/2016.
 */
public class Solution {
    private String answer;

    public Solution(String answer) {
        this.answer = answer;
    }

    public String getAnswer() {
        return answer;
    }
}
