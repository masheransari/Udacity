package com.example.android.booklisting;

/**
 * Created by wolfgang on 04.07.16.
 */
public interface OnRestTaskCompleted
{
    void onRestTaskCompleted(String aResult);
}
