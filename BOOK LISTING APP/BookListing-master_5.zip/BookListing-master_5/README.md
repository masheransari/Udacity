# BookListing
The app provides a search field to query the Google Books API and display the results in a list. The app calls the API, gets the JSON response, parses it, and returns the data as an ArrayList of custom Book objects. The list is implemented with a ListView and populated using custom array-adapter. 

This project is created as part of the Udacity Android Basics Nanodegree by Google. You can read the project descriptions [here](https://github.com/udacity/Project-Descriptions-for-Review/blob/master/Beginner%20Android/Book_Listing.md)


